const AWS = require('aws-sdk');
const S3 = new AWS.S3();
const BUCKET_NAME = 'smart-brain-profile-picture';

const getContentType = (fileName) => {
    const extension = fileName.split('.').pop().toLowerCase();
    const types = {
        jpeg: 'image/jpeg',
        jpg: 'image/jpeg',
        png: 'image/png',
        avif: 'image/avif',
        // Add more types as needed
    };
    return types[extension] || 'application/octet-stream'; // Default type
};

exports.uploadProfilePicture = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    
    const body = JSON.parse(event.body);
    console.log('Parsed body:', body);

    const { file } = body;
    console.log('Base64 string length:', file.length);

    const buffer = Buffer.from(file, 'base64');
    const fileName = `profile-pictures/${Date.now()}_${body.fileName}`;
    const contentType = getContentType(body.fileName);

    const params = {
        Bucket: BUCKET_NAME,
        Key: fileName,
        Body: buffer,
        ContentType: contentType
    };

    try {
        await S3.upload(params).promise();
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                message: 'Upload Successful',
                url: `https://${BUCKET_NAME}.s3.amazonaws.com/${fileName}`
            })
        };
    } catch (error) {
        console.error('Error uploading to S3', error.message);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Could not upload image'})
        };
    }
}; 